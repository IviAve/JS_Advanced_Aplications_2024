const baseUrl = "http://localhost:3030/users";

export { baseUrl };
