const section = document.getElementById("loginPage");

export function showLogin(context) {
  context.showSection(section);
}
