const section = document.getElementById("createPage");

export function showCreate(context) {
  context.showSection(section);
}
