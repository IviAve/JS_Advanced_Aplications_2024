const section = document.getElementById("registerPage");

export function showRegister(context) {
  context.showSection(section);
}
