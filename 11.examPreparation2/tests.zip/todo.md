Framework:
[x] Rendering and routing utils
[x] app.js with router init
[ ] Request module
[ ] LocalStorage and other utils
[ ] user service

Implementation:
[ ] Read description
[ ] Check project files
[ ] Install dependecies
[ ] Prepare HTML templates
[ ] Adapt user service
[ ] Create collection service
 - [ ] Read all
 - [ ] Read details by ID
 - [ ] Create
 - [ ] Update
 - [ ] Delete
[ ] Implement views
 - [ ] Home
 - [ ] Catalog
 - [ ] Login
 - [ ] Register
 - [ ] Navigation
 - [ ] Create
 - [ ] Details
 - [ ] Edit 
[ ] BONUS 
